<?php
/**
 * Created by PhpStorm.
 * User: junade
 * Date: 19/07/2016
 * Time: 01:51
 */

require_once('Dice.php');

$dice = new Dice();

var_dump($dice->roll());