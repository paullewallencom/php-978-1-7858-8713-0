<?php

/**
 * Created by PhpStorm.
 * User: junade
 * Date: 19/07/2016
 * Time: 14:34
 */
class Human
{
    public $name;
    public $dateOfBirth;
    public $height;
    public $weight;
}