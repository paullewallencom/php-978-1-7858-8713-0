<?php

/**
 * User: Junade Ali
 * Date: 10/04/2016
 * Time: 10:50
 */
interface Shape
{
    public function draw();
}