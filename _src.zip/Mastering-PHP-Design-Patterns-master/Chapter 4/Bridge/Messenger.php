<?php

/**
 * User: Junade Ali
 * Date: 10/04/2016
 * Time: 13:34
 */
interface Messenger
{
    public function send($body);
}