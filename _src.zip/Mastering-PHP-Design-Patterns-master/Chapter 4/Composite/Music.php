<?php

/**
 * User: Junade Ali
 * Date: 10/04/2016
 * Time: 13:03
 */

interface Music
{
    public function play();
}