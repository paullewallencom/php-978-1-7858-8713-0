<?php
/**
 * User: Junade Ali
 * Date: 18/01/2016
 * Time: 21:06
 */

namespace IcyApril\ChapterOne;

class Book
{
    public function __construct()
    {
        echo "Hello world!";
    }
}