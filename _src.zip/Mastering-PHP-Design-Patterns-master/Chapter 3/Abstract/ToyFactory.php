<?php

/**
 * User: Junade Ali
 * Date: 12/03/2016
 * Time: 08:34
 */
interface ToyFactory {
    function makeMaze();
    function makePuzzle();
}